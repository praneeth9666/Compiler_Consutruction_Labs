x = eval(input())
while (int(x != 23)):
    print(42)
    x = x + 1

