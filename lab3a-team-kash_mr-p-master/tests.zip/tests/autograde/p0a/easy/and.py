x = 2 and 3
print(x)