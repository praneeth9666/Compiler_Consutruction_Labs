if int(eval(input()) == 23):
    print(42)
else:
    print(0)
