x = 12
is_positive = 1
if int(x != 0):
    is_positive = 0

print(is_positive)
