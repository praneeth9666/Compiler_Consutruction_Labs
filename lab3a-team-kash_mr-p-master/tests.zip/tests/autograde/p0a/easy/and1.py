x = 1
y = 2
z = 3
w = 4
v = x + y + z + w
print((x and y) and (z and w))
v = v + v + v + v
print(v and v)
