x = 1
y = 100
while (int(x != y)):
  x = x + 1
  print(x and y)