x = 1 or 2
print(x)