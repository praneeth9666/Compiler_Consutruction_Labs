x = int(not 2)
print(x)
