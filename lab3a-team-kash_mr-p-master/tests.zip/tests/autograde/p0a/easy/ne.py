print(int(1 != 2))
