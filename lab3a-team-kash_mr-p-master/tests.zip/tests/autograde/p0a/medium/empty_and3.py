print(int(1 == 2) and int(4 == 5))
