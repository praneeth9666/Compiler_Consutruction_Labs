print(int(1 != 0) and int(0 != 0))
