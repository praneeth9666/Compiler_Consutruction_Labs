while (eval(input())):
    print(1)