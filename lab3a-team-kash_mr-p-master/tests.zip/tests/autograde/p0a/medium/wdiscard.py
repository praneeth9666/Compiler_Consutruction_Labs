x = 10
while (int(x != 0)):
    x = x + -1
    eval(input())