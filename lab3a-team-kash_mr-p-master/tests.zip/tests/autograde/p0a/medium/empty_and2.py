print(1 and int(1 == 3) and 4)
