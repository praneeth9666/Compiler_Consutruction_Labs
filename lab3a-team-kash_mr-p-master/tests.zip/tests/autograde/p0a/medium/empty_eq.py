print(int(0 == 0))
