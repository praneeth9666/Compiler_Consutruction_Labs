print(int((not 0)) + 1)
# 
