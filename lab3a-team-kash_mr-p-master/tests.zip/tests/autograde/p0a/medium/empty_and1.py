print(int((1 and 2) == (3 and 5)))
