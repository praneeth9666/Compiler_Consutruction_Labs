x = 0
while int(not x):
    x = eval(input())
    
