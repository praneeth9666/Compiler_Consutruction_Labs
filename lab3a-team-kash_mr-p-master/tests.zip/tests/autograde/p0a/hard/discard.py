x = eval(input())
if (int(x != 23)):
    y = eval(input())
    if (int(y != 42)):
        x = x + 1
    else:
        x = x + 2
else:
    x = x + 3


