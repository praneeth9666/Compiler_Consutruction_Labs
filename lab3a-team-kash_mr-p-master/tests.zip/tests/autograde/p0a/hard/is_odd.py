is_odd = 1
x = eval(input())
idx = 1
while int(idx != x):
    is_odd = int(not is_odd)
    idx = idx + 1
print(is_odd)
