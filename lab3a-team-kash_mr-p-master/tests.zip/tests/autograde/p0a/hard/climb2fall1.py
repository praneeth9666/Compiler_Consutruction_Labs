climb = 2
fall = 1
peak = 40
while int(fall != peak):
    climb = fall + 2
    fall = climb + -1
