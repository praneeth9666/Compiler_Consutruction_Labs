x = 2
y = 10
while int(x != 23):
    if int(x + -y != 12):
        x = x + y
    else:
        x = x + 1
