x = 2
y = -x
print(x)
print(y)