x = eval(input())
print(x + 1)