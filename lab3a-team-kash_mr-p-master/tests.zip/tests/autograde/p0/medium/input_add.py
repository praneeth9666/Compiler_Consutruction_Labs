x = eval(input())
y = eval(input()) + x
z = eval(input()) + y
w = eval(input()) + z
print(x + y + z + w + eval(input()))
