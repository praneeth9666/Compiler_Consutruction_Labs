x = 2
y = 3
print(x)
print(y)
tmp = x
x = y
y = tmp
print(x)
print(y)
