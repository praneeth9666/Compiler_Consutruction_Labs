tmp0 = -eval(input())
tmp1 = tmp0 + 23
tmp0 = eval(input())
tmp2 = tmp0 + tmp1
print(tmp2)
