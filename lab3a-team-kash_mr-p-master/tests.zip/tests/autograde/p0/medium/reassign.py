tmp0 = 23
tmp0 = tmp0 + 1
print(tmp0)
