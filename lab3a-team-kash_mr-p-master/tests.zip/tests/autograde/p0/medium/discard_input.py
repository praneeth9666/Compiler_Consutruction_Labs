eval(input()) + eval(input())
eval(input())