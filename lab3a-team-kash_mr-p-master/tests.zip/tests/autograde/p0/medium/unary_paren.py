x = -(1 + -2)
print(x)
