x = 12
print((3 + (2 + -((eval(input()) + (x + -2) + -x)))))