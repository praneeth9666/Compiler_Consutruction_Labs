z = 4
w = 0
z = 1
x = w + z
y = x + 1
w = y
print(w)