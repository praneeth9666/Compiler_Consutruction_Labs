x = 20 + ----30
print(x)