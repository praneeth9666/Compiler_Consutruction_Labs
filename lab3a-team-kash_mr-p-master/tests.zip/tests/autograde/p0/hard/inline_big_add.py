x = 51474836
print(x + x + x + x + x + x + x + x)