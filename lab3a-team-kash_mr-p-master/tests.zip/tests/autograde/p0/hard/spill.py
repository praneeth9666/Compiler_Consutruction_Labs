x = 1
y = 2
z = 3
w = 23
v = -2
k = 12
print(x + y + z + w + v + k)