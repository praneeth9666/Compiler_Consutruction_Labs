tmp0 = 1
tmp1 = 2
tmp3 = tmp0 + tmp1
tmp4 = tmp1 + tmp3
print(tmp3 + tmp4)