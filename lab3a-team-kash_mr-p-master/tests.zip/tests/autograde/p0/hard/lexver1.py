_tmp1 = 23
tmp2_ = -6
tmp_3 = 12
print(_tmp1 + tmp2_ + tmp_3)
print(tmp2_ + tmp_3)