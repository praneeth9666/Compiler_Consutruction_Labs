print(eval(input()) + 1)
