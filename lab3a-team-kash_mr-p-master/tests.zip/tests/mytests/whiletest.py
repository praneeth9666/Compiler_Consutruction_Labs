x = 0
while int(x != 20):
    print(x)
    x = x+1