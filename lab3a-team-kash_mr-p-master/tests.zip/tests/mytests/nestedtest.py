x = 5
y = 10
if int(eval(input()) == 23):
    if y + x == 15:
        print(y + x)
    else:
        print(-1)
else:
    print(y+-x)