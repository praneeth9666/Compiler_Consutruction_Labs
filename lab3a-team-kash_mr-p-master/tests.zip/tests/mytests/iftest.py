x = 5
y = 10
if int(eval(input()) == 23):
    print(y+x)
else:
    print(y+-x)